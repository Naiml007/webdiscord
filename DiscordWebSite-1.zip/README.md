Free discord bot site template. Not the best, but using variables so it's easy to change things on it. 

To change the colors go to styles.css and change the color on main-color and --secondary. Changing the background color is also allowed, but not recomened as the text doesn't use variables, and somethings may end up looking bad.



It isn't the best, but I made it in about an hour. 
